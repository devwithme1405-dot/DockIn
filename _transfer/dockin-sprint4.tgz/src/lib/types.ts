// Every record carries sync-ready fields so the local database can later be
// mirrored to Supabase without changing the shape of the data.
export interface Base {
  id: string;
  createdAt: number;
  updatedAt: number;
  deletedAt?: number | null;
}

export type ThemePref = "system" | "light" | "dark";

export interface Profile {
  id: "me";
  name: string;
  /** Required attendance, in percent (Bennett default is 75). */
  target: number;
  theme: ThemePref;
  onboarded: boolean;
  /** Monthly spending budget in rupees (0 or missing = not set). */
  budget?: number;
  createdAt: number;
  updatedAt: number;
}

export interface Subject extends Base {
  name: string;
  code: string;
  color: string;
  /** Classes already attended / held before starting to use DockIn. */
  baseAttended?: number;
  baseTotal?: number;
}

export type ClassKind = "lecture" | "practical";

export interface Slot extends Base {
  subjectId: string;
  /** 0 = Sunday ... 6 = Saturday (same as JavaScript's Date.getDay). */
  weekday: number;
  start: string; // "HH:MM" 24h
  end: string;
  kind: ClassKind;
  room?: string;
  /** How many attendance units this class is worth (default 1). */
  weight: number;
}

export type SessionStatus =
  | "unmarked"
  | "present"
  | "absent"
  | "cancelled"
  | "holiday";

export interface Session extends Base {
  /** Deterministic id: `${slotId}:${date}` so a day is never generated twice. */
  slotId: string;
  subjectId: string;
  date: string; // "YYYY-MM-DD" local date
  start: string;
  end: string;
  kind: ClassKind;
  weight: number;
  status: SessionStatus;
}

export type AttendanceState = "none" | "safe" | "warn" | "danger";

export interface AttendanceSummary {
  attended: number;
  total: number;
  /** Percentage 0-100, or null when no class has been marked yet. */
  pct: number | null;
  /** Classes that can still be missed while staying at or above the target. */
  canMiss: number;
  /** Classes that must be attended in a row to get back to the target. */
  mustAttend: number;
  state: AttendanceState;
}

export type ExpenseCategory =
  | "food"
  | "snacks"
  | "travel"
  | "shopping"
  | "study"
  | "bills"
  | "fun"
  | "other";

export interface Expense extends Base {
  /** Amount in rupees (decimals allowed). */
  amount: number;
  category: ExpenseCategory;
  note: string;
  date: string; // "YYYY-MM-DD" local date
}
