import { CalendarDays } from "lucide-react";
import { ComingSoon } from "@/components/ComingSoon";

export default function CalendarPage() {
  return (
    <ComingSoon
      title="Calendar"
      icon={CalendarDays}
      points={[
        "Month and agenda views of classes, deadlines and exams",
        "Bennett holidays and exam weeks",
      ]}
    />
  );
}
