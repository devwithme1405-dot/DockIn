import { ListChecks } from "lucide-react";
import { ComingSoon } from "@/components/ComingSoon";

export default function TasksPage() {
  return (
    <ComingSoon
      title="Tasks"
      icon={ListChecks}
      points={[
        "Assignments with due dates and reminders",
        "Exam countdowns and syllabus checklists",
      ]}
    />
  );
}
