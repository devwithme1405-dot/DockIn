"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { saveProfile, seedSampleTimetable } from "@/lib/repo";
import { Button, Chip, Field, cx, inputCls } from "@/components/ui";

type Start = "sample" | "empty";

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [target, setTarget] = useState(75);
  const [start, setStart] = useState<Start>("sample");
  const [busy, setBusy] = useState(false);

  async function finish() {
    setBusy(true);
    await saveProfile({ name: name.trim(), target, onboarded: true });
    if (start === "sample") await seedSampleTimetable();
    router.replace("/");
  }

  return (
    <div className="flex min-h-dvh flex-col px-6 pt-[max(2rem,env(safe-area-inset-top))] pb-[max(1.5rem,env(safe-area-inset-bottom))]">
      <div className="flex items-center gap-1.5" aria-label={`Step ${step + 1} of 3`}>
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className={cx(
              "h-1 flex-1 rounded-full transition-colors",
              i <= step ? "bg-accent" : "bg-surface-2",
            )}
          />
        ))}
      </div>

      <div className="flex-1 pt-10">
        {step === 0 && (
          <>
            <p className="text-sm font-semibold tracking-wide text-accent">DockIn</p>
            <h1 className="mt-2 text-[30px] font-semibold leading-tight tracking-tight">
              Your whole college day, one tap away.
            </h1>
            <p className="mt-3 text-muted">
              Attendance first. Money, assignments and exams come next. Everything stays on
              this phone for now.
            </p>
            <div className="mt-8">
              <Field label="What should we call you?">
                <input
                  className={inputCls}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your first name"
                  autoComplete="given-name"
                />
              </Field>
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <h1 className="text-[28px] font-semibold leading-tight tracking-tight">
              Required attendance
            </h1>
            <p className="mt-3 text-muted">
              Bennett asks for 75%. DockIn will tell you how many classes you can still miss
              against this number.
            </p>
            <div className="mt-8 flex flex-wrap gap-2.5">
              {[75, 70, 65, 80, 85].map((t) => (
                <Chip key={t} active={target === t} onClick={() => setTarget(t)}>
                  {t}%
                </Chip>
              ))}
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <h1 className="text-[28px] font-semibold leading-tight tracking-tight">
              Set up your timetable
            </h1>
            <p className="mt-3 text-muted">
              You can change every subject and class later.
            </p>
            <div className="mt-8 space-y-3">
              <Choice
                selected={start === "sample"}
                onClick={() => setStart("sample")}
                title="Start with a sample"
                body="5 subjects and a Mon to Fri Bennett CSE week. Edit the times to match yours."
              />
              <Choice
                selected={start === "empty"}
                onClick={() => setStart("empty")}
                title="Start empty"
                body="I will add my own subjects and classes."
              />
            </div>
          </>
        )}
      </div>

      <div className="flex gap-3">
        {step > 0 && (
          <Button variant="secondary" onClick={() => setStep(step - 1)} disabled={busy}>
            Back
          </Button>
        )}
        {step < 2 ? (
          <Button className="flex-1" onClick={() => setStep(step + 1)}>
            Continue
          </Button>
        ) : (
          <Button className="flex-1" onClick={finish} disabled={busy}>
            {busy ? "Setting up…" : "Start using DockIn"}
          </Button>
        )}
      </div>
    </div>
  );
}

function Choice({
  selected,
  onClick,
  title,
  body,
}: {
  selected: boolean;
  onClick: () => void;
  title: string;
  body: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={cx(
        "w-full rounded-2xl border-2 p-4 text-left transition",
        selected ? "border-accent bg-accent-soft" : "border-line bg-surface",
      )}
    >
      <p className="font-medium">{title}</p>
      <p className="mt-0.5 text-sm text-muted">{body}</p>
    </button>
  );
}
