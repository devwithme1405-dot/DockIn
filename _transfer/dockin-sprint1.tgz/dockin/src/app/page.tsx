"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useLiveQuery } from "dexie-react-hooks";
import { Check, ChevronLeft, ChevronRight, Minus, Settings, X } from "lucide-react";
import { getProfile, ensureSessionsForDate, setSessionStatus } from "@/lib/repo";
import { useAttendanceStats, useSessionsOn, useSlots } from "@/lib/hooks";
import { addDays, fmtDayLong, fmtTime, relativeDayLabel, toDateStr } from "@/lib/dates";
import { describe, fmtPct } from "@/lib/attendance";
import type { Session, SessionStatus } from "@/lib/types";
import {
  EmptyState,
  PageHeader,
  STATE_SOFT,
  STATE_TEXT,
  cx,
  useToast,
} from "@/components/ui";

export default function TodayPage() {
  const profile = useLiveQuery(() => getProfile(), []);
  const [today] = useState(() => toDateStr());
  const [date, setDate] = useState(today);
  const target = profile?.target ?? 75;

  const data = useAttendanceStats(target);
  const slots = useSlots();
  const sessions = useSessionsOn(date);

  useEffect(() => {
    ensureSessionsForDate(date);
  }, [date, slots]);

  const subjectById = useMemo(
    () => new Map(data?.subjects.map((s) => [s.id, s]) ?? []),
    [data],
  );

  const attention = useMemo(() => {
    if (!data) return [];
    return data.stats
      .filter((s) => s.summary.state === "danger" || s.summary.state === "warn")
      .sort((a, b) => (a.summary.pct ?? 0) - (b.summary.pct ?? 0));
  }, [data]);

  if (!profile || !data) return null;

  const hasTimetable = (slots?.length ?? 0) > 0;
  const overall = data.overall;

  let headline = "Safe in all subjects";
  let headState = overall.state;
  if (overall.state === "none") {
    headline = "Mark a class to start tracking";
  } else if (attention.length > 0) {
    const worst = attention[0];
    headState = worst.summary.state;
    const name = worst.subject.code || worst.subject.name;
    headline =
      worst.summary.state === "danger"
        ? `${name} is at ${fmtPct(worst.summary.pct)}`
        : `${name} is close to the line`;
  }

  return (
    <>
      <PageHeader
        subtitle={fmtDayLong(today)}
        title={profile.name ? `Hey, ${profile.name}` : "Today"}
        right={
          <Link
            href="/settings"
            aria-label="Settings"
            className="grid size-10 place-items-center rounded-full bg-surface-2 text-muted"
          >
            <Settings size={20} />
          </Link>
        }
      />

      <section
        className={cx("mx-5 rounded-2xl p-4", STATE_SOFT[headState])}
        aria-label="Attendance status"
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className={cx("text-[17px] font-semibold leading-snug", STATE_TEXT[headState])}>
              {headline}
            </p>
            {attention[0] && (
              <p className="mt-0.5 text-sm text-text/80">{describe(attention[0].summary)}</p>
            )}
            {overall.state !== "none" && attention.length > 1 && (
              <p className="mt-1 text-[13px] text-muted">
                +{attention.length - 1} more need attention
              </p>
            )}
          </div>
          <div className="text-right">
            <p className="text-[28px] font-semibold leading-none tabular-nums">
              {fmtPct(overall.pct)}
            </p>
            <p className="mt-1 text-xs text-muted">overall</p>
          </div>
        </div>
      </section>

      <div className="mt-6 flex items-center justify-between px-5">
        <h2 className="text-[17px] font-semibold">
          {relativeDayLabel(date, today)}
          {date !== today && (
            <span className="ml-2 text-sm font-normal text-muted">{fmtDayLong(date)}</span>
          )}
        </h2>
        <div className="flex items-center gap-1">
          <button
            aria-label="Previous day"
            onClick={() => setDate(addDays(date, -1))}
            className="grid size-9 place-items-center rounded-full bg-surface-2"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            aria-label="Next day"
            onClick={() => setDate(addDays(date, 1))}
            className="grid size-9 place-items-center rounded-full bg-surface-2"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="mt-3 space-y-2.5 px-5">
        {sessions === undefined ? null : sessions.length === 0 ? (
          <div className="-mx-5">
            <EmptyState
              title={hasTimetable ? "No classes this day" : "No timetable yet"}
              body={
                hasTimetable
                  ? "Enjoy the free time."
                  : "Add your subjects and weekly classes to see them here."
              }
              action={
                !hasTimetable && (
                  <Link
                    href="/attendance/timetable"
                    className="rounded-xl bg-accent px-4 py-2.5 text-sm font-medium text-on-accent"
                  >
                    Set up timetable
                  </Link>
                )
              }
            />
          </div>
        ) : (
          sessions.map((s) => (
            <ClassRow
              key={s.id}
              session={s}
              name={subjectById.get(s.subjectId)?.name ?? "Subject"}
              code={subjectById.get(s.subjectId)?.code ?? ""}
              color={subjectById.get(s.subjectId)?.color ?? "#888"}
            />
          ))
        )}
      </div>

      {attention.length > 0 && (
        <section className="mt-7 px-5">
          <h2 className="mb-2 text-[17px] font-semibold">Needs attention</h2>
          <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-surface">
            {attention.map(({ subject, summary }) => (
              <li key={subject.id}>
                <Link
                  href={`/attendance/${subject.id}`}
                  className="flex items-center justify-between gap-3 px-4 py-3"
                >
                  <div className="min-w-0">
                    <p className="truncate font-medium">{subject.name}</p>
                    <p className={cx("text-sm", STATE_TEXT[summary.state])}>
                      {describe(summary)}
                    </p>
                  </div>
                  <span className="text-[17px] font-semibold tabular-nums">
                    {fmtPct(summary.pct)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </>
  );
}

const ACTIONS: {
  status: SessionStatus;
  label: string;
  icon: typeof Check;
  on: string;
}[] = [
  { status: "present", label: "Present", icon: Check, on: "bg-safe text-white" },
  { status: "absent", label: "Absent", icon: X, on: "bg-danger text-white" },
  { status: "cancelled", label: "Cancelled", icon: Minus, on: "bg-text text-bg" },
];

function ClassRow({
  session,
  name,
  code,
  color,
}: {
  session: Session;
  name: string;
  code: string;
  color: string;
}) {
  const toast = useToast();

  async function mark(next: SessionStatus) {
    const prev = session.status;
    const status = prev === next ? "unmarked" : next;
    await setSessionStatus(session.id, status);
    toast.show(
      status === "unmarked"
        ? "Cleared"
        : `${code || name}: ${status === "cancelled" ? "class cancelled" : `marked ${status}`}`,
      () => setSessionStatus(session.id, prev),
    );
  }

  return (
    <article className="overflow-hidden rounded-2xl bg-surface">
      <div className="flex">
        <div className="w-1.5 shrink-0" style={{ background: color }} aria-hidden />
        <div className="min-w-0 flex-1 p-3.5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{name}</p>
              <p className="text-[13px] text-muted tabular-nums">
                {fmtTime(session.start)} to {fmtTime(session.end)}
              </p>
            </div>
            <span className="shrink-0 rounded-md bg-surface-2 px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide text-muted">
              {session.kind === "practical" ? "Lab" : "Lecture"}
            </span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2" role="group" aria-label={`Mark ${name}`}>
            {ACTIONS.map(({ status, label, icon: Icon, on }) => {
              const selected = session.status === status;
              return (
                <button
                  key={status}
                  onClick={() => mark(status)}
                  aria-pressed={selected}
                  className={cx(
                    "flex h-10 items-center justify-center gap-1.5 rounded-xl text-sm font-medium transition active:scale-[0.97]",
                    selected ? on : "bg-surface-2 text-text",
                  )}
                >
                  <Icon size={16} strokeWidth={2.5} />
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </article>
  );
}
