import { Wallet } from "lucide-react";
import { ComingSoon } from "@/components/ComingSoon";

export default function MoneyPage() {
  return (
    <ComingSoon
      title="Money"
      icon={Wallet}
      points={[
        "Add an expense in two taps",
        "Monthly budget and category breakdown",
        "Quick-add shortcut from the iPhone back tap",
      ]}
    />
  );
}
