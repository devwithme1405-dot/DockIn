"use client";

import Link from "next/link";
import { useLiveQuery } from "dexie-react-hooks";
import { CalendarClock } from "lucide-react";
import { getProfile } from "@/lib/repo";
import { useAttendanceStats } from "@/lib/hooks";
import { describe, fmtPct } from "@/lib/attendance";
import {
  EmptyState,
  PageHeader,
  ProgressBar,
  STATE_TEXT,
  cx,
} from "@/components/ui";

export default function AttendancePage() {
  const profile = useLiveQuery(() => getProfile(), []);
  const target = profile?.target ?? 75;
  const data = useAttendanceStats(target);
  if (!profile || !data) return null;

  const { stats, overall } = data;

  return (
    <>
      <PageHeader
        title="Attendance"
        right={
          <Link
            href="/attendance/timetable"
            className="flex h-10 items-center gap-1.5 rounded-full bg-surface-2 px-3.5 text-sm font-medium"
          >
            <CalendarClock size={16} />
            Timetable
          </Link>
        }
      />

      <section className="mx-5 rounded-2xl bg-surface p-4">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-[13px] text-muted">Overall</p>
            <p
              className={cx(
                "text-[40px] font-semibold leading-none tabular-nums",
                STATE_TEXT[overall.state],
              )}
            >
              {fmtPct(overall.pct)}
            </p>
          </div>
          <div className="text-right text-[13px] text-muted">
            <p>Target {target}%</p>
            <p className="tabular-nums">
              {overall.attended} of {overall.total} classes
            </p>
          </div>
        </div>
        <div className="mt-4">
          <ProgressBar pct={overall.pct} target={target} state={overall.state} />
        </div>
      </section>

      <h2 className="mt-7 mb-2 px-5 text-[17px] font-semibold">Subjects</h2>
      {stats.length === 0 ? (
        <EmptyState
          title="No subjects yet"
          body="Add your subjects and weekly classes in the timetable."
          action={
            <Link
              href="/attendance/timetable"
              className="rounded-xl bg-accent px-4 py-2.5 text-sm font-medium text-on-accent"
            >
              Open timetable
            </Link>
          }
        />
      ) : (
        <ul className="space-y-2.5 px-5">
          {stats.map(({ subject, summary }) => (
            <li key={subject.id}>
              <Link
                href={`/attendance/${subject.id}`}
                className="block rounded-2xl bg-surface p-4 transition active:scale-[0.99]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <span
                      className="size-2.5 shrink-0 rounded-full"
                      style={{ background: subject.color }}
                      aria-hidden
                    />
                    <div className="min-w-0">
                      <p className="truncate font-medium">{subject.name}</p>
                      <p className="text-[13px] text-muted tabular-nums">
                        {subject.code && `${subject.code} · `}
                        {summary.attended} of {summary.total} classes
                      </p>
                    </div>
                  </div>
                  <p
                    className={cx(
                      "text-[22px] font-semibold leading-none tabular-nums",
                      STATE_TEXT[summary.state],
                    )}
                  >
                    {fmtPct(summary.pct)}
                  </p>
                </div>
                <div className="mt-3">
                  <ProgressBar pct={summary.pct} target={target} state={summary.state} />
                </div>
                <p className={cx("mt-2 text-sm", STATE_TEXT[summary.state])}>
                  {describe(summary)}
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
