"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useLiveQuery } from "dexie-react-hooks";
import { ChevronLeft } from "lucide-react";
import { db } from "@/lib/db";
import { getProfile, setSessionStatus, setSubjectBase } from "@/lib/repo";
import { describe, fmtPct, summarize, withBase } from "@/lib/attendance";
import { fmtDay, fmtTime } from "@/lib/dates";
import type { Session, SessionStatus } from "@/lib/types";
import {
  Button,
  Chip,
  Field,
  ProgressBar,
  STATE_TEXT,
  Sheet,
  cx,
  inputCls,
  useToast,
} from "@/components/ui";

const STATUS_LABEL: Record<SessionStatus, string> = {
  unmarked: "Not marked",
  present: "Present",
  absent: "Absent",
  cancelled: "Cancelled",
  holiday: "Holiday",
};
const STATUS_STYLE: Record<SessionStatus, string> = {
  unmarked: "bg-surface-2 text-muted",
  present: "bg-safe-soft text-safe",
  absent: "bg-danger-soft text-danger",
  cancelled: "bg-surface-2 text-muted",
  holiday: "bg-accent-soft text-accent",
};

export default function SubjectPage() {
  const { id } = useParams<{ id: string }>();
  const profile = useLiveQuery(() => getProfile(), []);
  const subject = useLiveQuery(() => db.subjects.get(id), [id]);
  const sessions = useLiveQuery(
    async () =>
      (await db.sessions.where("subjectId").equals(id).toArray())
        .filter((s) => !s.deletedAt)
        .sort((a, b) => (a.date + a.start < b.date + b.start ? 1 : -1)),
    [id],
  );
  const [editing, setEditing] = useState<Session | null>(null);
  const toast = useToast();

  const target = profile?.target ?? 75;
  const [baseOpen, setBaseOpen] = useState(false);
  const summary = useMemo(
    () => summarize(withBase(sessions ?? [], subject ?? undefined), target),
    [sessions, subject, target],
  );

  if (!profile || subject === undefined || sessions === undefined) return null;
  if (!subject || subject.deletedAt) {
    return (
      <div className="p-5">
        <Link href="/attendance" className="text-accent">
          Back to attendance
        </Link>
        <p className="mt-6 text-muted">This subject no longer exists.</p>
      </div>
    );
  }

  async function change(s: Session, status: SessionStatus) {
    const prev = s.status;
    await setSessionStatus(s.id, status);
    setEditing(null);
    toast.show("Updated", () => setSessionStatus(s.id, prev));
  }

  return (
    <>
      <header className="px-3 pt-[max(1rem,env(safe-area-inset-top))]">
        <Link
          href="/attendance"
          className="inline-flex h-10 items-center gap-1 rounded-full px-2 text-accent"
        >
          <ChevronLeft size={20} />
          Attendance
        </Link>
      </header>

      <div className="px-5 pt-1">
        <div className="flex items-center gap-2.5">
          <span className="size-3 rounded-full" style={{ background: subject.color }} aria-hidden />
          <h1 className="text-[24px] font-semibold tracking-tight">{subject.name}</h1>
        </div>
        {subject.code && <p className="mt-0.5 text-sm text-muted">{subject.code}</p>}
      </div>

      <section className="mx-5 mt-4 rounded-2xl bg-surface p-4">
        <div className="flex items-end justify-between">
          <p
            className={cx(
              "text-[44px] font-semibold leading-none tabular-nums",
              STATE_TEXT[summary.state],
            )}
          >
            {fmtPct(summary.pct)}
          </p>
          <p className="pb-1 text-sm text-muted">Target {target}%</p>
        </div>
        <div className="mt-4">
          <ProgressBar pct={summary.pct} target={target} state={summary.state} />
        </div>
        <p className={cx("mt-3 font-medium", STATE_TEXT[summary.state])}>{describe(summary)}</p>
        <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-line pt-4 text-center">
          <Stat label="Attended" value={summary.attended} />
          <Stat label="Held" value={summary.total} />
          <Stat
            label={summary.state === "danger" ? "Must attend" : "Can miss"}
            value={
              summary.state === "none"
                ? "--"
                : summary.state === "danger"
                  ? Number.isFinite(summary.mustAttend)
                    ? summary.mustAttend
                    : "All"
                  : Number.isFinite(summary.canMiss)
                    ? summary.canMiss
                    : "Any"
            }
          />
        </dl>
      </section>

      <section className="mx-5 mt-3 flex items-center justify-between rounded-2xl bg-surface px-4 py-3">
        <div>
          <p className="text-sm font-medium">Before DockIn</p>
          <p className="text-[13px] text-muted tabular-nums">
            {subject.baseTotal
              ? `${subject.baseAttended ?? 0} of ${subject.baseTotal} classes`
              : "Add the classes you already attended this semester"}
          </p>
        </div>
        <Button variant="secondary" size="sm" onClick={() => setBaseOpen(true)}>
          {subject.baseTotal ? "Edit" : "Add"}
        </Button>
      </section>

      <h2 className="mt-7 mb-2 px-5 text-[17px] font-semibold">History</h2>
      {sessions.length === 0 ? (
        <p className="px-5 text-sm text-muted">
          Classes appear here once their day has been opened on the Today screen.
        </p>
      ) : (
        <ul className="mx-5 divide-y divide-line overflow-hidden rounded-2xl bg-surface">
          {sessions.map((s) => (
            <li key={s.id}>
              <button
                onClick={() => setEditing(s)}
                className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
              >
                <div>
                  <p className="font-medium">{fmtDay(s.date)}</p>
                  <p className="text-[13px] text-muted tabular-nums">
                    {fmtTime(s.start)} · {s.kind === "practical" ? "Lab" : "Lecture"}
                  </p>
                </div>
                <span
                  className={cx(
                    "rounded-full px-2.5 py-1 text-xs font-medium",
                    STATUS_STYLE[s.status],
                  )}
                >
                  {STATUS_LABEL[s.status]}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}

      <BaseSheet
        key={`${subject.id}:${subject.baseAttended ?? 0}:${subject.baseTotal ?? 0}`}
        open={baseOpen}
        onClose={() => setBaseOpen(false)}
        initialAttended={subject.baseAttended ?? 0}
        initialTotal={subject.baseTotal ?? 0}
        onSave={(a, t) => setSubjectBase(subject.id, a, t)}
      />

      <Sheet
        open={!!editing}
        onClose={() => setEditing(null)}
        title={editing ? `${fmtDay(editing.date)} · ${fmtTime(editing.start)}` : ""}
      >
        <div className="flex flex-wrap gap-2 pb-2">
          {(["present", "absent", "cancelled", "holiday", "unmarked"] as SessionStatus[]).map(
            (st) => (
              <Chip
                key={st}
                active={editing?.status === st}
                onClick={() => editing && change(editing, st)}
              >
                {STATUS_LABEL[st]}
              </Chip>
            ),
          )}
        </div>
      </Sheet>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div>
      <dd className="text-[20px] font-semibold tabular-nums">{value}</dd>
      <dt className="text-xs text-muted">{label}</dt>
    </div>
  );
}

function BaseSheet({
  open,
  onClose,
  initialAttended,
  initialTotal,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  initialAttended: number;
  initialTotal: number;
  onSave: (attended: number, total: number) => Promise<void>;
}) {
  const [attended, setAttended] = useState(String(initialAttended || ""));
  const [total, setTotal] = useState(String(initialTotal || ""));
  const a = Number(attended || 0);
  const t = Number(total || 0);
  const valid =
    Number.isInteger(a) && Number.isInteger(t) && a >= 0 && t >= 0 && a <= t;

  return (
    <Sheet open={open} onClose={onClose} title="Classes before DockIn">
      <p className="mb-4 text-sm text-muted">
        Check your college portal and enter the totals so far this semester. DockIn adds
        every class you mark from now on.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Attended">
          <input
            className={inputCls}
            inputMode="numeric"
            value={attended}
            onChange={(e) => setAttended(e.target.value.replace(/\D/g, ""))}
            placeholder="18"
          />
        </Field>
        <Field label="Total held">
          <input
            className={inputCls}
            inputMode="numeric"
            value={total}
            onChange={(e) => setTotal(e.target.value.replace(/\D/g, ""))}
            placeholder="22"
          />
        </Field>
      </div>
      {!valid && (
        <p className="mb-3 text-sm text-danger">Attended cannot be more than total held.</p>
      )}
      <Button
        className="w-full"
        disabled={!valid}
        onClick={async () => {
          await onSave(a, t);
          onClose();
        }}
      >
        Save
      </Button>
    </Sheet>
  );
}
