import type { AttendanceSummary, Session, Subject } from "./types";

/**
 * Attendance maths.
 *
 * With `a` attended and `t` held (weighted), target fraction `p`:
 *   - can still miss m classes while a / (t + m) >= p  ->  m = floor(a / p - t)
 *   - must attend n classes in a row so (a + n) / (t + n) >= p
 *                                              ->  n = ceil((p * t - a) / (1 - p))
 * Cancelled, holiday and unmarked classes are not counted.
 */
export function summarize(
  sessions: Pick<Session, "status" | "weight">[],
  targetPct: number,
): AttendanceSummary {
  let attended = 0;
  let total = 0;
  for (const s of sessions) {
    if (s.status === "present") {
      attended += s.weight;
      total += s.weight;
    } else if (s.status === "absent") {
      total += s.weight;
    }
  }

  if (total === 0) {
    return {
      attended: 0,
      total: 0,
      pct: null,
      canMiss: 0,
      mustAttend: 0,
      state: "none",
    };
  }

  const p = Math.min(Math.max(targetPct, 0), 100) / 100;
  const pct = (attended / total) * 100;
  const EPS = 1e-9;

  let canMiss = 0;
  let mustAttend = 0;
  if (p === 0) {
    canMiss = Infinity;
  } else if (attended / total + EPS >= p) {
    canMiss = Math.max(0, Math.floor(attended / p - total + EPS));
  } else if (p < 1) {
    mustAttend = Math.max(0, Math.ceil((p * total - attended) / (1 - p) - EPS));
  } else {
    mustAttend = Infinity;
  }

  let state: AttendanceSummary["state"];
  if (pct + EPS < targetPct) state = "danger";
  else if (canMiss < 2) state = "warn";
  else state = "safe";

  return { attended, total, pct, canMiss, mustAttend, state };
}

export function fmtPct(pct: number | null): string {
  if (pct === null) return "--";
  const r = Math.round(pct * 10) / 10;
  return Number.isInteger(r) ? `${r}%` : `${r.toFixed(1)}%`;
}

/** One short, plain-language line describing a summary. */
export function describe(s: AttendanceSummary): string {
  if (s.state === "none") return "No classes marked yet";
  if (s.state === "danger") {
    return Number.isFinite(s.mustAttend)
      ? `Attend the next ${s.mustAttend} ${s.mustAttend === 1 ? "class" : "classes"}`
      : "Below target";
  }
  if (!Number.isFinite(s.canMiss)) return "Nothing to worry about";
  if (s.canMiss === 0) return "No bunk left. Attend the next class";
  return `Can miss ${s.canMiss} more ${s.canMiss === 1 ? "class" : "classes"}`;
}

type Weighted = Pick<Session, "status" | "weight">;

/** Sessions plus the "before DockIn" starting numbers of a subject. */
export function withBase(
  sessions: Weighted[],
  base: Pick<Subject, "baseAttended" | "baseTotal"> | undefined,
): Weighted[] {
  const total = base?.baseTotal ?? 0;
  const attended = Math.min(base?.baseAttended ?? 0, total);
  if (total <= 0) return sessions;
  const extra: Weighted[] = [{ status: "present", weight: attended }];
  if (total > attended) extra.push({ status: "absent", weight: total - attended });
  return [...extra, ...sessions];
}
