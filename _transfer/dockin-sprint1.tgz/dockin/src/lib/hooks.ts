"use client";

import { useMemo } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "./db";
import { summarize, withBase } from "./attendance";
import type { AttendanceSummary, Session, Slot, Subject } from "./types";

export function useSubjects(): Subject[] | undefined {
  return useLiveQuery(
    async () =>
      (await db.subjects.filter((s) => !s.deletedAt).toArray()).sort(
        (a, b) => a.createdAt - b.createdAt,
      ),
    [],
  );
}

export function useSlots(): Slot[] | undefined {
  return useLiveQuery(
    () => db.slots.filter((s) => !s.deletedAt).toArray(),
    [],
  );
}

export function useSessionsOn(date: string): Session[] | undefined {
  return useLiveQuery(
    async () =>
      (
        await db.sessions
          .where("date")
          .equals(date)
          .filter((s) => !s.deletedAt)
          .toArray()
      ).sort((a, b) => a.start.localeCompare(b.start)),
    [date],
  );
}

export function useAllSessions(): Session[] | undefined {
  return useLiveQuery(
    () => db.sessions.filter((s) => !s.deletedAt).toArray(),
    [],
  );
}

export interface SubjectStat {
  subject: Subject;
  summary: AttendanceSummary;
}

/** Per-subject and overall attendance, recomputed live as classes are marked. */
export function useAttendanceStats(target: number) {
  const subjects = useSubjects();
  const sessions = useAllSessions();

  return useMemo(() => {
    if (!subjects || !sessions) return undefined;
    const bySubject = new Map<string, Session[]>();
    for (const s of sessions) {
      const list = bySubject.get(s.subjectId);
      if (list) list.push(s);
      else bySubject.set(s.subjectId, [s]);
    }
    const stats: SubjectStat[] = subjects.map((subject) => ({
      subject,
      summary: summarize(withBase(bySubject.get(subject.id) ?? [], subject), target),
    }));
    const live = new Set(subjects.map((s) => s.id));
    let all: Pick<Session, "status" | "weight">[] = sessions.filter((s) =>
      live.has(s.subjectId),
    );
    for (const subject of subjects) all = withBase(all, subject);
    const overall = summarize(all, target);
    return { stats, overall, subjects };
  }, [subjects, sessions, target]);
}
