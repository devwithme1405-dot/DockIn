"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { X } from "lucide-react";
import type { AttendanceState } from "@/lib/types";

export function cx(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}

// ---------- state colours ----------

export const STATE_TEXT: Record<AttendanceState, string> = {
  none: "text-muted",
  safe: "text-safe",
  warn: "text-warn",
  danger: "text-danger",
};
export const STATE_BAR: Record<AttendanceState, string> = {
  none: "bg-muted",
  safe: "bg-safe",
  warn: "bg-warn",
  danger: "bg-danger",
};
export const STATE_SOFT: Record<AttendanceState, string> = {
  none: "bg-surface-2",
  safe: "bg-safe-soft",
  warn: "bg-warn-soft",
  danger: "bg-danger-soft",
};

// ---------- button ----------

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "md" | "sm";
};

export function Button({
  variant = "primary",
  size = "md",
  className,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.98] disabled:opacity-40 disabled:active:scale-100",
        size === "md" ? "h-12 px-5 text-[15px]" : "h-9 px-3.5 text-sm",
        variant === "primary" && "bg-accent text-on-accent",
        variant === "secondary" && "bg-surface-2 text-text",
        variant === "ghost" && "text-accent",
        variant === "danger" && "bg-danger-soft text-danger",
        className,
      )}
    />
  );
}

// ---------- bottom sheet ----------

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
      <div className="anim-fade absolute inset-0 bg-black/45" onClick={onClose} />
      <div className="anim-sheet absolute inset-x-0 bottom-0 mx-auto max-h-[88dvh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-surface px-5 pt-3 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-2xl">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line" />
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="grid size-9 place-items-center rounded-full bg-surface-2 text-muted"
          >
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ---------- toast with undo ----------

interface ToastApi {
  show: (message: string, onUndo?: () => void) => void;
}
const ToastCtx = createContext<ToastApi>({ show: () => {} });
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<{
    id: number;
    message: string;
    onUndo?: () => void;
  } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback((message: string, onUndo?: () => void) => {
    if (timer.current) clearTimeout(timer.current);
    setToast({ id: Date.now(), message, onUndo });
    timer.current = setTimeout(() => setToast(null), 4000);
  }, []);

  const api = useMemo(() => ({ show }), [show]);

  return (
    <ToastCtx.Provider value={api}>
      {children}
      {toast && (
        <div
          key={toast.id}
          className="pointer-events-none fixed inset-x-0 bottom-[calc(4.75rem+env(safe-area-inset-bottom))] z-[60] mx-auto flex max-w-md justify-center px-4"
        >
          <div className="anim-toast pointer-events-auto flex items-center gap-4 rounded-xl bg-text px-4 py-2.5 text-sm text-bg shadow-lg">
            <span>{toast.message}</span>
            {toast.onUndo && (
              <button
                className="font-semibold underline-offset-2 hover:underline"
                onClick={() => {
                  toast.onUndo?.();
                  setToast(null);
                }}
              >
                Undo
              </button>
            )}
          </div>
        </div>
      )}
    </ToastCtx.Provider>
  );
}

// ---------- small pieces ----------

export function ProgressBar({
  pct,
  target,
  state,
}: {
  pct: number | null;
  target: number;
  state: AttendanceState;
}) {
  return (
    <div className="relative h-2 w-full overflow-hidden rounded-full bg-surface-2">
      <div
        className={cx("h-full rounded-full transition-[width] duration-500", STATE_BAR[state])}
        style={{ width: `${Math.min(Math.max(pct ?? 0, 0), 100)}%` }}
      />
      <div
        className="absolute top-0 h-full w-0.5 bg-text/60"
        style={{ left: `${target}%` }}
        aria-hidden
      />
    </div>
  );
}

export function Chip({
  children,
  active,
  onClick,
  className,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  const base = cx(
    "inline-flex h-9 items-center rounded-full px-3.5 text-sm font-medium transition",
    active ? "bg-text text-bg" : "bg-surface-2 text-text",
    className,
  );
  if (!onClick) return <span className={base}>{children}</span>;
  return (
    <button type="button" onClick={onClick} className={base} aria-pressed={active}>
      {children}
    </button>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="mb-4 block">
      <span className="mb-1.5 block text-[13px] font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export const inputCls =
  "h-12 w-full rounded-xl border border-line bg-bg px-3.5 text-text outline-none placeholder:text-muted/70 focus:border-accent";

export function PageHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <header className="flex items-end justify-between px-5 pt-[max(1.25rem,env(safe-area-inset-top))] pb-3">
      <div>
        {subtitle && <p className="text-[13px] text-muted">{subtitle}</p>}
        <h1 className="text-[26px] font-semibold tracking-tight">{title}</h1>
      </div>
      {right}
    </header>
  );
}

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mx-5 rounded-2xl border border-dashed border-line px-6 py-10 text-center">
      <p className="font-medium">{title}</p>
      {body && <p className="mt-1 text-sm text-muted">{body}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}
