"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useLiveQuery } from "dexie-react-hooks";
import {
  ArrowRight,
  CalendarCheck,
  Check,
  ChevronLeft,
  ChevronRight,
  Flame,
  GraduationCap,
  ListChecks,
  Minus,
  Settings,
  Wallet,
  X,
} from "lucide-react";
import { ensureSessionsSince, getProfile, setSessionStatus } from "@/lib/repo";
import { useAttendanceStats, useSessionsOn, useSlots } from "@/lib/hooks";
import {
  addDays,
  fmtDayLong,
  fmtDuration,
  fmtTime,
  greetingFor,
  nowHM,
  relativeDayLabel,
  toDateStr,
  toMinutes,
  weekdayOf,
  WEEKDAYS_LONG,
} from "@/lib/dates";
import { computeStreak, describe, fmtPct } from "@/lib/attendance";
import type { Session, SessionStatus, Slot, Subject } from "@/lib/types";
import {
  EmptyState,
  Ring,
  STATE_TEXT,
  SubjectTile,
  cx,
  useToast,
} from "@/components/ui";

function useNow(): { today: string; hm: string } {
  const [now, setNow] = useState(() => ({ today: toDateStr(), hm: nowHM() }));
  useEffect(() => {
    const id = setInterval(() => setNow({ today: toDateStr(), hm: nowHM() }), 30_000);
    return () => clearInterval(id);
  }, []);
  return now;
}

export default function TodayPage() {
  const profile = useLiveQuery(() => getProfile(), []);
  const { today, hm } = useNow();
  const [picked, setPicked] = useState<string | null>(null);
  const date = picked ?? today;
  const target = profile?.target ?? 75;

  const data = useAttendanceStats(target);
  const slots = useSlots();
  const sessions = useSessionsOn(date);
  const todaySessions = useSessionsOn(today);

  // Create the classes of every day since the user joined (max 30 days back),
  // so missed days show up as "not marked" and can be caught up on.
  const joined = profile ? toDateStr(new Date(profile.createdAt)) : null;
  useEffect(() => {
    if (!joined) return;
    const earliest = addDays(today, -30);
    ensureSessionsSince(joined > earliest ? joined : earliest, today);
  }, [joined, today, slots]);

  const subjectById = useMemo(
    () => new Map(data?.subjects.map((s) => [s.id, s]) ?? []),
    [data],
  );

  const attention = useMemo(() => {
    if (!data) return [];
    return data.stats
      .filter((s) => s.summary.state === "danger" || s.summary.state === "warn")
      .sort((a, b) => (a.summary.pct ?? 0) - (b.summary.pct ?? 0));
  }, [data]);

  const streak = useMemo(
    () => (data ? computeStreak(data.sessions, today) : 0),
    [data, today],
  );

  const unmarkedPast = useMemo(() => {
    if (!data) return { count: 0, latest: null as string | null };
    const live = new Set(data.subjects.map((s) => s.id));
    const list = data.sessions.filter(
      (s) => s.date < today && s.status === "unmarked" && live.has(s.subjectId),
    );
    const latest = list.reduce<string | null>(
      (m, s) => (m === null || s.date > m ? s.date : m),
      null,
    );
    return { count: list.length, latest };
  }, [data, today]);

  if (!profile || !data) return null;

  const overall = data.overall;
  const name = profile.name || "there";

  return (
    <>
      <header className="flex items-center justify-between px-5 pt-[max(1.25rem,env(safe-area-inset-top))] pb-4">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-full bg-accent text-[17px] font-semibold text-on-accent">
            {name[0]?.toUpperCase()}
          </span>
          <div>
            <p className="text-[13px] text-muted">{greetingFor()}</p>
            <h1 className="text-[22px] font-semibold leading-tight tracking-tight">{name}</h1>
          </div>
        </div>
        <Link
          href="/settings"
          aria-label="Settings"
          className="grid size-10 place-items-center rounded-full bg-surface text-muted shadow-[0_0_0_1px_var(--line)]"
        >
          <Settings size={19} />
        </Link>
      </header>

      <DayHero
        today={today}
        hm={hm}
        sessions={todaySessions}
        subjectById={subjectById}
        slots={slots ?? []}
      />

      {(streak > 0 || (overall.state !== "none" && Number.isFinite(overall.canMiss))) && (
        <div className="mt-3 flex flex-wrap gap-2 px-5">
          {streak > 0 && (
            <span className="inline-flex h-8 items-center gap-1.5 rounded-full bg-warn-soft px-3 text-[13px] font-medium text-warn">
              <Flame size={15} /> {streak}-day marking streak
            </span>
          )}
          {overall.state !== "none" && overall.state !== "danger" && Number.isFinite(overall.canMiss) && (
            <span className="inline-flex h-8 items-center rounded-full bg-surface px-3 text-[13px] font-medium text-muted shadow-[0_0_0_1px_var(--line)]">
              Bunk budget: {overall.canMiss} {overall.canMiss === 1 ? "class" : "classes"}
            </span>
          )}
        </div>
      )}

      <section className="mt-5 grid grid-cols-2 gap-3 px-5" aria-label="Overview">
        <Link
          href="/attendance"
          className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--line)] transition active:scale-[0.98]"
        >
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-medium text-muted">Attendance</span>
            <CalendarCheck size={17} className="text-muted" />
          </div>
          <div className="mt-3 flex items-center gap-3">
            <Ring pct={overall.pct} state={overall.state} size={52} stroke={6} />
            <div className="min-w-0">
              <p
                className={cx(
                  "text-[24px] font-semibold leading-none tabular-nums",
                  STATE_TEXT[overall.state],
                )}
              >
                {fmtPct(overall.pct)}
              </p>
              <p className="mt-1 truncate text-xs text-muted">
                {overall.state === "none"
                  ? "Mark a class"
                  : attention.length > 0
                    ? `${attention.length} to watch`
                    : "All subjects safe"}
              </p>
            </div>
          </div>
        </Link>

        <SoonTile href="/money" label="Spent this month" icon={Wallet} value="₹ --" hint="Coming soon" />
        <SoonTile href="/tasks" label="Due this week" icon={ListChecks} value="-- tasks" hint="Coming soon" />
        <SoonTile href="/tasks" label="Next exam" icon={GraduationCap} value="-- days" hint="Coming soon" />
      </section>

      {unmarkedPast.count > 0 && (
        <button
          onClick={() => setPicked(unmarkedPast.latest)}
          className="mx-5 mt-5 flex w-[calc(100%-2.5rem)] items-center justify-between rounded-2xl bg-accent-soft px-4 py-3 text-left"
        >
          <span>
            <span className="block text-[15px] font-semibold text-accent">
              {unmarkedPast.count} past {unmarkedPast.count === 1 ? "class is" : "classes are"} not marked
            </span>
            <span className="block text-[13px] text-muted">Catch up to keep your numbers right</span>
          </span>
          <ArrowRight size={18} className="text-accent" />
        </button>
      )}

      <div className="mt-6 flex items-center justify-between px-5">
        <h2 className="text-[17px] font-semibold">
          {relativeDayLabel(date, today)}
          {date !== today && (
            <span className="ml-2 text-sm font-normal text-muted">{fmtDayLong(date)}</span>
          )}
        </h2>
        <div className="flex items-center gap-1">
          {date !== today && (
            <button
              onClick={() => setPicked(null)}
              className="mr-1 h-9 rounded-full px-3 text-sm font-medium text-accent"
            >
              Today
            </button>
          )}
          <button
            aria-label="Previous day"
            onClick={() => setPicked(addDays(date, -1))}
            className="grid size-9 place-items-center rounded-full bg-surface shadow-[0_0_0_1px_var(--line)]"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            aria-label="Next day"
            onClick={() => setPicked(addDays(date, 1))}
            className="grid size-9 place-items-center rounded-full bg-surface shadow-[0_0_0_1px_var(--line)]"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="mt-3 px-5">
        {sessions === undefined ? null : sessions.length === 0 ? (
          <div className="-mx-5">
            <EmptyState
              title={(slots?.length ?? 0) > 0 ? "No classes this day" : "No timetable yet"}
              body={
                (slots?.length ?? 0) > 0
                  ? "Enjoy the free time."
                  : "Add your subjects and weekly classes to see them here."
              }
              action={
                (slots?.length ?? 0) === 0 && (
                  <Link
                    href="/attendance/timetable"
                    className="rounded-xl bg-accent px-4 py-2.5 text-sm font-medium text-on-accent"
                  >
                    Set up timetable
                  </Link>
                )
              }
            />
          </div>
        ) : (
          <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-surface shadow-[0_0_0_1px_var(--line)]">
            {sessions.map((s) => (
              <ClassRow
                key={s.id}
                session={s}
                subject={subjectById.get(s.subjectId)}
                live={date === today && toMinutes(s.start) <= toMinutes(hm) && toMinutes(hm) < toMinutes(s.end)}
              />
            ))}
          </ul>
        )}
      </div>

      {attention.length > 0 && (
        <section className="mt-7 px-5">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-[17px] font-semibold">Needs attention</h2>
            <Link href="/attendance" className="text-sm font-medium text-accent">
              See all
            </Link>
          </div>
          <ul className="divide-y divide-line overflow-hidden rounded-2xl bg-surface shadow-[0_0_0_1px_var(--line)]">
            {attention.slice(0, 3).map(({ subject, summary }) => (
              <li key={subject.id}>
                <Link
                  href={`/attendance/${subject.id}`}
                  className="flex items-center gap-3 px-4 py-3"
                >
                  <SubjectTile name={subject.name} code={subject.code} color={subject.color} size={38} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{subject.name}</p>
                    <p className={cx("text-[13px]", STATE_TEXT[summary.state])}>
                      {describe(summary)}
                    </p>
                  </div>
                  <span
                    className={cx(
                      "text-[17px] font-semibold tabular-nums",
                      STATE_TEXT[summary.state],
                    )}
                  >
                    {fmtPct(summary.pct)}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </>
  );
}

// ---------- hero card ----------

const DOT: Record<SessionStatus, string> = {
  present: "bg-[#47c98f]",
  absent: "bg-[#ff7a70]",
  cancelled: "bg-white/35",
  holiday: "bg-white/35",
  unmarked: "bg-white/15",
};

function DayHero({
  today,
  hm,
  sessions,
  subjectById,
  slots,
}: {
  today: string;
  hm: string;
  sessions: Session[] | undefined;
  subjectById: Map<string, Subject>;
  slots: Slot[];
}) {
  const nowMin = toMinutes(hm);
  const list = sessions ?? [];
  const ongoing = list.find((s) => toMinutes(s.start) <= nowMin && nowMin < toMinutes(s.end));
  const next = list.find((s) => toMinutes(s.start) > nowMin);
  const marked = list.filter((s) => s.status !== "unmarked").length;

  let eyebrow = "Today";
  let title = "No classes today";
  let sub = fmtDayLong(today);

  if (list.length > 0) {
    if (ongoing) {
      const sub1 = subjectById.get(ongoing.subjectId);
      eyebrow = "Happening now";
      title = sub1?.name ?? "Class";
      sub = `Until ${fmtTime(ongoing.end)} · ${fmtDuration(toMinutes(ongoing.end) - nowMin)} left`;
    } else if (next) {
      const sub1 = subjectById.get(next.subjectId);
      eyebrow = "Up next";
      title = sub1?.name ?? "Class";
      sub = `${fmtTime(next.start)} · in ${fmtDuration(toMinutes(next.start) - nowMin)}`;
    } else {
      eyebrow = "Done for the day";
      title = marked === list.length ? "All classes marked" : "Classes are over";
      sub =
        marked === list.length
          ? "Nice. Nothing left to track."
          : `${list.length - marked} still to mark`;
    }
  } else {
    // find the next day that has a class
    for (let i = 1; i <= 7; i++) {
      const d = addDays(today, i);
      const wd = weekdayOf(d);
      const first = slots
        .filter((s) => s.weekday === wd)
        .sort((a, b) => a.start.localeCompare(b.start))[0];
      if (first) {
        const sub1 = subjectById.get(first.subjectId);
        eyebrow = "Free day";
        title = "No classes today";
        sub = `Next: ${sub1?.name ?? "class"} on ${i === 1 ? "tomorrow" : WEEKDAYS_LONG[wd]}, ${fmtTime(first.start)}`;
        break;
      }
    }
  }

  return (
    <section className="mx-5 rounded-3xl bg-hero p-5 text-hero-fg" aria-label="Today at a glance">
      <p className="text-[13px] font-medium text-hero-muted">
        {eyebrow} · {fmtDayLong(today)}
      </p>
      <p className="mt-2 text-[24px] font-semibold leading-tight tracking-tight">{title}</p>
      <p className="mt-1 text-[15px] text-hero-muted">{sub}</p>

      {list.length > 0 && (
        <div className="mt-5">
          <div className="flex gap-1.5" role="img" aria-label={`${marked} of ${list.length} classes marked`}>
            {list.map((s) => (
              <span key={s.id} className={cx("h-1.5 flex-1 rounded-full", DOT[s.status])} />
            ))}
          </div>
          <p className="mt-2 text-xs text-hero-muted tabular-nums">
            {marked} of {list.length} classes marked
          </p>
        </div>
      )}
    </section>
  );
}

// ---------- tiles and rows ----------

function SoonTile({
  href,
  label,
  icon: Icon,
  value,
  hint,
}: {
  href: string;
  label: string;
  icon: typeof Wallet;
  value: string;
  hint: string;
}) {
  return (
    <Link
      href={href}
      className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--line)] transition active:scale-[0.98]"
    >
      <div className="flex items-center justify-between">
        <span className="text-[13px] font-medium text-muted">{label}</span>
        <Icon size={17} className="text-muted" />
      </div>
      <p className="mt-3 text-[24px] font-semibold leading-none tabular-nums text-muted/60">{value}</p>
      <p className="mt-1 text-xs text-muted">{hint}</p>
    </Link>
  );
}

const ACTIONS: {
  status: SessionStatus;
  label: string;
  icon: typeof Check;
  on: string;
}[] = [
  { status: "present", label: "Present", icon: Check, on: "bg-safe text-white" },
  { status: "absent", label: "Absent", icon: X, on: "bg-danger text-white" },
  { status: "cancelled", label: "Cancelled", icon: Minus, on: "bg-text text-bg" },
];

function ClassRow({
  session,
  subject,
  live,
}: {
  session: Session;
  subject: Subject | undefined;
  live: boolean;
}) {
  const toast = useToast();
  const name = subject?.name ?? "Subject";
  const code = subject?.code ?? "";

  async function mark(next: SessionStatus) {
    const prev = session.status;
    const status = prev === next ? "unmarked" : next;
    await setSessionStatus(session.id, status);
    toast.show(
      status === "unmarked"
        ? "Cleared"
        : `${code || name}: ${status === "cancelled" ? "class cancelled" : `marked ${status}`}`,
      () => setSessionStatus(session.id, prev),
    );
  }

  return (
    <li className={cx("flex items-center gap-3 px-3.5 py-3", live && "bg-accent-soft")}>
      <div className="w-[2.6rem] shrink-0 text-center leading-tight tabular-nums">
        <p className="text-[15px] font-semibold">{fmtTime(session.start).replace(/ (am|pm)/, "")}</p>
        <p className="text-[11px] uppercase text-muted">{fmtTime(session.start).slice(-2)}</p>
      </div>
      <span className="h-9 w-1 shrink-0 self-center rounded-full" style={{ background: subject?.color ?? "#888" }} aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="line-clamp-2 text-[15px] font-medium leading-snug">{name}</p>
        <p className="truncate text-[13px] text-muted">
          {session.kind === "practical" ? "Lab" : "Lecture"} · until {fmtTime(session.end)}
          {live && <span className="ml-1.5 font-semibold text-accent">· Now</span>}
        </p>
      </div>
      <div className="flex shrink-0 gap-1" role="group" aria-label={`Mark ${name}`}>
        {ACTIONS.map(({ status, label, icon: Icon, on }) => {
          const selected = session.status === status;
          return (
            <button
              key={status}
              onClick={() => mark(status)}
              aria-pressed={selected}
              aria-label={label}
              title={label}
              className={cx(
                "grid size-9 place-items-center rounded-xl transition active:scale-95",
                selected ? on : "bg-surface-2 text-muted",
              )}
            >
              <Icon size={18} strokeWidth={2.5} />
            </button>
          );
        })}
      </div>
    </li>
  );
}
